# Area of circle

import numpy as np
import matplotlib.pyplot as plt

N = 100000

radius = 1

X = np.random.uniform(low=-radius,high=radius,size=N)
Y = np.random.uniform(low=-radius,high=radius,size=N)

R = np.sqrt(X**2 + Y**2)

box_size = (2.0 * radius) ** 2

is_point_inside = R < radius
N_inside = np.sum(is_point_inside)
area_of_circle = box_size * N_inside / N
plt.scatter(X,Y,c=is_point_inside,s=5.0,edgecolors="none",cmap=plt.cm.Paired)
plt.axis("equal")

print(area_of_circle)
print(area_of_circle/radius**2)



# Linear Regression

import numpy as np
import matplotlib.pyplot as plt
def estimate_coeff(x,y):
  n = len(x)
  ss_n = n*np.sum(x*y) - np.sum(x)*np.sum(y)
  ss_d = n*np.sum(x**2) - np.sum(x)**2

  slope = ss_n/ss_d
  inter = (np.sum(y) - slope*np.sum(x))/n

  return (slope , inter)

def plot_regression(x,y,b):
  y_pred = b[0] * x + b[1]

  plt.scatter(x,y,s=20.0,color="r")
  plt.plot(x,y_pred,color="g")
  plt.xlabel("X")
  plt.ylabel("X")

x = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
y = np.array([1, 3, 2, 5, 7, 8, 8, 9, 10, 12])

# estimating coefficients
b = estimate_coeff(x, y)
print(b)
plot_regression(x,y,b)
